=========================================================================================================================
                Password Saver

*******************USE AT YOUR OWN RISK*******************
This software can be freely distributed.  It is not necessary, but I would appreciate some recognition in the code files:
       (c) Spotted Plaid Productions - Gary Malandro.
     
         Description:  With all of the usernames, passwords, security codes, security questions, etc it can become difficult to 
                       remember all of them while still keeping the password secure.  This program creates a database to store these
                       values, using a single password or passphrase to encrypt.  The important information is securely stored in the database.
                       As many credentials as needed can be created to associate with an app or url.  So in addition to the required login information,
                       recovery options can also be securely stored.
                       Example:
                                New app/url: - www.yahoo.com
                                Credentials:
                                    Challenge           Response - Actual values would be entered below for the response
                                     Login               <username>
                                     Password            <password>
                                     Security Question   <answer>

Requirements:  
   Developed using Java 1.7
   Eclipse 4.3 (Kepler)
   sqlite-jdbc-3.7.2.jar - http://www.xerial.org/maven/repository/artifact/org/xerial/sqlite-jdbc/3.7.2/
   WindowBuilder Pro Plugin - WindowBuilder Pro Update Site - http://dl.google.com/eclipse/inst/d2wbpro/latest/3.7


Hope you find this useful!
   